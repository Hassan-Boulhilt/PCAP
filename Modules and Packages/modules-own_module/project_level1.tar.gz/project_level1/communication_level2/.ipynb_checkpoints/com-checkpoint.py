def fun():
    print("Hi from level 2 under folder Communication_level2 in module com.py")