def fun():
    print("Hi from level 2 under folder messaging_level2 in module queue.py")