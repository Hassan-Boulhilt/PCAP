def fun():
    print("Hi from level 2 under folder Cors_level2 in module utils.py")