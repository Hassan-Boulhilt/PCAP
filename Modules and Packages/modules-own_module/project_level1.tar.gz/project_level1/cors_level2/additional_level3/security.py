def fun():
    print("Hi from level 3 under folder Cadditional_level3 in module security.py")